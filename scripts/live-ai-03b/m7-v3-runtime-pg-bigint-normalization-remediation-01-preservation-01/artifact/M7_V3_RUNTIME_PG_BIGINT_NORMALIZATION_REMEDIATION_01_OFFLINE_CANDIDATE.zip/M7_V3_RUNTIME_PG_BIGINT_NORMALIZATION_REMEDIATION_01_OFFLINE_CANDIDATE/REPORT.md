# V3 RUNTIME PG BIGINT NORMALIZATION REMEDIATION 01 — OFFLINE CANDIDATE

Status: **offline candidate for independent review**. Nothing here was deployed, pushed, committed, signed or run
against any live system. Baseline: `Sachinhelpline/staybid-frontend` commit `a2b84c4fc3acf14e2f63e6ffe3e4a80805833ae3`
(tree `24111eb96fd60b238292bb98fdf6106ce0b3d487`), clean workspace (0 changes before editing).

## A. Root cause — independently PROVEN

node-postgres (`pg` 8.23.0 / `pg-types` 2.2.0, the repo lockfile versions; no custom INT8 parser anywhere) returns
PostgreSQL `BIGINT` (OID 20) values as JavaScript **strings**. The frozen R3 runtime contract compares the same fields
as JavaScript **numbers**:

* `exactPredecessor` — `canonical(actual V1/V2 entries) === canonical(expected rows)`; expected rows are built by
  `G.entryRows` with `unit_size: 1000000`, `rate_micros: 2000000|…` (numbers);
* `dormant` — `x.session_money_ceiling_micros !== 0` … (7 fields) and `control_epoch === 1`;
* `checkV3Catalog` — `e.unit_size !== 1000000`, `e.rate_micros !== w[2]`, digest rebuild over the entry rows,
  `worstCaseMicros(...)`.

Reproduced on a throwaway PostgreSQL cluster seeded with the exact accepted V3 pre-activation state, using ONLY
unmodified accepted code (real pg → `makePgPhysicalFactory` → `establishReaderSession` → `makeGuardedReaderClientV3`
→ accepted `observeState` shape → frozen `checkPreActivationState`): result `predecessor_not_byte_exact`
(`evidence/repro-before-fix-real-pg.out`). Reproduced again **through the accepted PI01 core `run()`** with real
executor + reader sessions: `stage=pre_activation_observation reason=predecessor_not_byte_exact`, pre-mutation,
DB unchanged — exactly the live refusal (test A12/A13).

```
BEFORE  typeof actual  …v1-reasoning-input-token-base.unit_size === "string"  value "1000000"
EXPECTED typeof expected.unit_size === "number"  value 1000000
canonical(actual) !== canonical(expected)
AFTER   typeof normalized.unit_size === "number"  value 1000000
canonical(normalized predecessor rows) === canonical(expected rows)
```

Why the Owner-Mac SQL verifier said `predecessor_exact=true`: it compares inside PostgreSQL (jsonb), where the
values are numeric; the type split only exists after the driver hands rows to JavaScript. Why the accepted PI01
suites did not catch it: `m7-post-step67-production-integration-01-runtime-01/tests/run-all.mjs` injects fake
runtimes/rows with JavaScript numbers; no accepted test ever fed real PostgreSQL rows to the frozen checks.

**Additional finding (material):** with the unmodified reader path, `checkActivatedState` on a genuinely activated
database ALSO fails `predecessor_not_byte_exact` (test D09). Had the pre-check somehow passed, a committed
activation would have been reported `UNCERTAIN` (post-commit `activated_observation` failure).

## B. Exact BIGINT field surface (verified against schema + queries + runtime)

| frozen query (`QUERIES.*`) | BIGINT columns normalized | consumer |
|---|---|---|
| `catalogEntries` | `unit_size`, `rate_micros` | `exactPredecessor` (V1/V2), `checkV3Catalog` (V3 identity, rates, digest, worst case) |
| `policy` | `session_money_ceiling_micros`, `session_provider_calls`, `session_execution_admissions`, `subject_day_money_ceiling_micros`, `project_day_money_ceiling_micros`, `project_month_money_ceiling_micros`, `global_day_money_ceiling_micros` | `dormant` |
| `controls` | `control_epoch` | `dormant` |

Not normalized (verified no INT8): `catalogVersions` (text/timestamps via `to_char`, null), `ledger`
(text + `to_char(consumed_at)`); `verifyApprovalV3` reads no DB values; the activation receipt is a `jsonb` value
(JSON numbers/strings, no INT8 OID). Schema: all 10 columns `BIGINT NOT NULL` with `CHECK (>= 0)` (`unit_size > 0`).
Every family is individually necessary and the set is complete (A09/A10, repro STEP1–4):
normalize all-but-predecessor → `predecessor_not_byte_exact`; all-but-policy / all-but-control →
`dormant_policy_controls_mismatch`; all-but-V3-entries → `v3_entry_identity_mismatch`; all four → PASS.
Contract values are tiny (≤ 12 000 000), far inside `Number.MAX_SAFE_INTEGER`; no field under this contract can
legitimately exceed it, so Number conversion is contract-safe (no HOLD needed).

## C. Design (smallest safe fix)

The frozen R3 runtime is imported **inside** the accepted, byte-identical PI01 `production-composition.mjs`; the
only Authority-owned injection seam is `readerPhysicalFactory`. One new helper
`src/authority-v3-int8-observation-normalizer.mjs` (imported only by `authority-v3-composition.mjs`) wraps the
reader physical factory:

* normalizes **only** result rows of the three frozen observation SQL texts (exact string identity with
  `QUERIES.catalogEntries|policy|controls`) and **only** the 10 allowlisted columns;
* converts a value only if it is canonical non-negative decimal text `^(0|[1-9][0-9]{0,15})$`, round-trips
  `String(Number(v)) === v` and `Number.isSafeInteger` (or is already a safe non-negative integer Number);
* any other value (empty, whitespace, sign, fraction, exponent, leading zeros, non-numeric, > 2^53−1, null,
  boolean, bigint, unsafe/negative/fractional number) is left **byte-for-byte unchanged** → the frozen strict
  checks refuse deterministically. It never throws on data (a throw inside `run()` would be reported as
  `integration_execution_failed` + `uncertain`, a misleading class before any mutation);
* every other statement (session lifecycle SQL, the reader-attestation clock sampler, versions, ledger, anything
  else) returns the **same result object**; non-allowlisted columns untouched;
* the wrapped physical exposes exactly the accepted 5-member reader surface, delegating to the same connection;
  an unexpected underlying shape is closed and refused at `open()` (→ deterministic `reader_connection_failed`);
* no SQL of its own, no `pg` import, no global `setTypeParser`, no I/O, no new query authority.

Composition change: 3 lines added (comment, import, wrapped factory), 1 removed (unwrapped factory).

## D. Changed files (vs a2b84c4)

| file | status | before sha256 / blob | after sha256 / blob |
|---|---|---|---|
| `…/src/authority-v3-composition.mjs` | modified | `a0764f5c…08ce` / `2f981a7b…8a1c` | see MANIFEST.json |
| `…/src/authority-v3-int8-observation-normalizer.mjs` | added | — | see MANIFEST.json |
| `…/tests/int8-normalizer.test.mjs` | added (test) | — | see MANIFEST.json |
| `…/tests/localpg/authority-v3-int8-localpg.test.mjs` | added (test) | — | see MANIFEST.json |
| `…/tests/int8-remediation-static.test.mjs` | added (test) | — | see MANIFEST.json |
| `…/tests/run-bigint01.mjs` | added (test runner) | — | see MANIFEST.json |

No accepted test file was modified.

## E. Tests

* `int8-normalizer` (unit, no DB) — 143/143: allowlist exactness, E invalid text (25 forms), F unsafe
  (strings + numbers), G safe Number unchanged, H non-BIGINT/nullable untouched, passthrough identity for
  lifecycle/other SQL, frozen-contract consequence per family, wrapper surface, J no-write static properties.
* `authority-v3-int8-localpg` (REAL PostgreSQL 16.13 + real pg 8.23.0) — 53/53: A before-fix reproduction
  (direct + through the accepted core), B after-fix PASS, C full pre-activation contract, D activated state via the
  accepted core `run()` + frozen restricted activation adapter with a synthetic TEST approval/trust root
  (sole active V3, 3 entries, predecessors unchanged, policy/controls dormant, exact ledger row, one-shot refusal of a
  second run), I session contract (frozen `establishReaderSession`, token, read-only enforced by PostgreSQL,
  guarded-client refusal, passthrough, same backend, close), J zero writes from the wrapped observation.
  TEST doubles only for attestation transport/validation and reviewer-trust-root config.
* `int8-remediation-static` — 23/23: exact change set, exact composition diff, frozen trees byte-identical,
  frozen blobs, pin, helper reachability, no type-parser change, no SQL mutation, no secret material.
* Accepted suites, unchanged: authority-v3 84/84, executor-v2 60/60, oneshot 17/17, executor-v2-localpg 20/20,
  accepted PI01 runtime suite 52/52, accepted PI01 identity PASS, accepted static 28/31 with ONLY S23 (fails on the
  pristine a2b84c4 baseline too — requires HEAD cbcb2689) and S24/S25 (name exactly this candidate's file set).
* Aggregate `tests/run-bigint01.mjs`: **10/10 suites, 481 assertions, PASS**.

## F. Frozen R3 runtime / pin / approval impact

* A. Frozen R3 runtime bytes changed? **NO** (whole `m7-post-step67-fresh-successor-r3-preservation-02` tree
  byte-identical; `v3-runtime-contract.mjs` blob `235ea45b…`, `v3-query-registry.mjs` `61076cb9…`,
  `v3-digest-gen.mjs` `5ccebf2c…`).
* B. `PINNED_SUCCESSOR_RUNTIME_PIN_REF` changed? **NO** (`78804a86…203d`; `runtimePinRef(PINNED_RUNTIME_BINDING)`
  and `validateRuntimePreservationBinding` re-verified).
* C. Accepted runtime preservation binding changed? **NO** (`m7-post-step67-production-integration-01-runtime-01`
  byte-identical; accepted PI01 identity tool PASS).
* D. Pricing/catalog/evidence digests changed? **NO** (no catalog/evidence/digest source touched; V3 inactive
  `414d4844…`, active `bc389312…`, evidence `2e39555c…` unchanged).
* E. DB schema/data changed? **NO** (no SQL added; live DB never contacted).
* F. Does the existing unconsumed approval still bind the exact expected successor runtime pin? **YES.** The V3
  approval payload binds `target.successor_runtime_pin_ref = 78804a86…` (unchanged), the FIXED_V3 target/catalog/
  policy constants (unchanged), the evidence receipt id + content digest (unchanged), the reviewer fingerprint
  (Authority env, unchanged) and an execution window. It does **not** bind the PI01 Authority bridge source, the
  Authority commit or the deployment. `verifyApprovalV3` would therefore still accept it after this patch, as long
  as it is presented before its expiry **2026-10-09T11:20:09Z**, the ledger shows it unconsumed (true now), and the
  catalog window is open (until 2026-10-13T22:44:42Z).
* G. Recommendation: **re-sign after the remediated Authority is deployed**, and let the current approval lapse
  unused.
  * *Verifier-contract requirement:* none — re-signing is NOT required by the V3 contract.
  * *Operational/reviewer-assurance recommendation:* the deployed Authority code in the activation trust path
    (the reader observation bridge that decides pre/post state) changed after the reviewer signed; the approval
    attests pricing evidence + runtime pin, not this bridge. A fresh approval signed after the remediated code is
    reviewed and deployed records the reviewer's decision over the code that will actually run. Practically, the
    current approval expires ~23 h after this candidate was produced; review + an authorized redeploy are unlikely
    to complete safely inside that window, and racing an expiry is the wrong incentive.

## G. Live-state action counters (this gate)

Railway mutations 0 · Authority restart/redeploy 0 · Executor/Reader/Gateway actions 0 · live DB connections 0 ·
live DB mutations 0 · SQL01/02/03/06 0 · signing 0 · approvals created 0 · activation attempts 0 · one-shot lock
touched 0 · provider/OpenAI calls 0 · API keys 0 · G4/G5 0 · CORE-PROD 0 · GitHub writes 0 · commits/pushes 0.
Local throwaway PostgreSQL writes occurred ONLY inside the offline tests (activation of the throwaway catalog in D).

## H. Material caveats

1. Local server is PostgreSQL 16.13; live is 18.x. INT8→string is decided by the client driver (`pg-types`,
   OID 20), not by the server version; the live refusal reason matches the reproduction exactly.
2. Taking the fix live needs a separately authorized Authority redeploy to a new commit (not done here). A new
   deployment is a new container: the one-shot lock (container-local tmp) is fresh — an Owner decision, not a bypass.
3. The Owner-Mac activation artifact pins Authority deployment `a664fce2…`; after any redeploy that constant must be
   re-bound in a later gate (the one-shot file itself, blob `a6a8d159…`, is unchanged).
4. The real-PG suite is time-bound to the frozen V3 catalog window (skips = UNPROVEN after 2026-10-13T22:44:42Z).
5. Pre-existing, unchanged: the accepted `observeState` issues 4 concurrent queries on one pg Client
   (pg 8.23 DeprecationWarning; would break on pg@9). Out of scope; not modified.
6. The full core run in D uses TEST doubles for attestation/config; real attestation is covered by the accepted
   executor-v2-localpg suite (unchanged, PASS).

## Verdict

`V3_RUNTIME_PG_BIGINT_NORMALIZATION_REMEDIATION_01_OFFLINE_CANDIDATE_READY_FOR_INDEPENDENT_REVIEW`

// BEFORE-FIX reproduction (evidence tool, not part of the candidate). THROWAWAY local cluster only.
// Uses ONLY unmodified accepted code at a2b84c4: real pg 8.23.0 → makePgPhysicalFactory → establishReaderSession →
// makeGuardedReaderClientV3 → the accepted observeState shape → frozen checkPreActivationState / checkV3Catalog.
import { mkdtempSync, rmSync, readdirSync, existsSync, chownSync, writeFileSync, readFileSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { join } from "node:path";
import os from "node:os";
const REPO = process.argv[2];
const S = join(REPO, "scripts/live-ai-03b");
const R3 = join(S, "m7-post-step67-fresh-successor-r3-preservation-02/artifact/extracted");
const M7S1 = join(S, "m7-step1-hb1-consolidated-remediation-01");
const { makePgPhysicalFactory, establishReaderSession } = await import(join(S, "private-reader-production-integration-offline-01/reader-session.mjs"));
const { makeGuardedReaderClientV3 } = await import(join(S, "m7-post-step67-production-integration-01-runtime-01/src/v3-guarded-clients.mjs"));
const { QUERIES } = await import(join(R3, "src/v3-query-registry.mjs"));
const { checkPreActivationState } = await import(join(R3, "src/v3-runtime-contract.mjs"));
const G = await import(join(R3, "src/v3-digest-gen.mjs"));

const base = "/usr/lib/postgresql"; const BIN = join(base, readdirSync(base).filter((x) => existsSync(join(base, x, "bin", "initdb"))).sort((a, b) => Number(b) - Number(a))[0], "bin");
const asPg = (cmd, args, opts = {}) => spawnSync("runuser", ["-u", "postgres", "--", cmd, ...args], { encoding: "utf8", ...opts });
const BASE = mkdtempSync(join(os.tmpdir(), "lai03b-bigint01-repro-"));
chownSync(BASE, Number(spawnSync("id", ["-u", "postgres"], { encoding: "utf8" }).stdout.trim()), Number(spawnSync("id", ["-g", "postgres"], { encoding: "utf8" }).stdout.trim()));
const DATA = join(BASE, "data");
process.on("exit", () => { asPg(join(BIN, "pg_ctl"), ["-D", DATA, "-m", "immediate", "stop"]); try { rmSync(BASE, { recursive: true, force: true }); } catch {} });
const psql = (db, input) => asPg(join(BIN, "psql"), ["-X", "-q", "-h", BASE, "-U", "postgres", "-d", db, "-v", "ON_ERROR_STOP=1"], { input });
asPg(join(BIN, "initdb"), ["-D", DATA, "-A", "trust", "-U", "postgres", "-N", "--no-instructions"]);
writeFileSync(join(DATA, "pg_hba.conf"), "local all all trust\n"); spawnSync("chown", ["postgres:postgres", join(DATA, "pg_hba.conf")]);
asPg(join(BIN, "pg_ctl"), ["-D", DATA, "-l", join(BASE, "server.log"), "-w", "-t", "60", "-o", `-c listen_addresses='' -c unix_socket_directories=${BASE} -c fsync=off`, "start"]);
psql("postgres", "CREATE DATABASE railway ENCODING 'UTF8' TEMPLATE template0;");
for (const f of [join(REPO, "migrations/2026-09-16-live-ai-budget-01-dpbel-foundation.sql"), join(REPO, "migrations/2026-09-16-live-ai-budget-01-dormant-control-policy-seed.sql"),
  join(REPO, "migrations/2026-09-18-live-ai-budget-01-inactive-price-catalog-seed.sql"), join(S, "trusted-runtime-live-binding-offline-01/trusted-reader-role.sql"),
  join(M7S1, "tests/seed-m5-roles.sql"), join(S, "trusted-activation-boundary-01/db/2026-09-19-p1-02-trusted-activation-boundary.sql"),
  join(S, "trusted-boundary-post-apply-offline-01/deferred-ledger-read-grant.sql"), join(S, "trusted-runtime-live-binding-offline-01/gateway-store-role.sql"),
  join(M7S1, "sql/m7-v2-01-inactive-catalog-seed.sql"), join(M7S1, "sql/m7-v2-02-trusted-successor-migration.sql"),
  join(R3, "sql/m7-v3-01-inactive-catalog-seed.sql"), join(R3, "sql/m7-v3-02-trusted-successor-migration.sql")]) {
  const r = psql("railway", readFileSync(f, "utf8")); if (r.status !== 0) { console.log("SEED_FAIL", f.split("/").pop(), (r.stderr || "").split("\n")[0]); process.exit(1); }
}
const env = { LAI03B_REPRO_READER_URL: `postgresql://live_ai_03b_reader@/railway?host=${encodeURIComponent(BASE)}` };
const phys = await makePgPhysicalFactory({ env, connectionStringEnvName: "LAI03B_REPRO_READER_URL" }).open();
const s = await establishReaderSession(phys, { statementTimeoutMs: 2000 });
console.log("reader_session_ok", s.ok, "role_enforced_read_only", s.ok);
const reader = makeGuardedReaderClientV3(s.session, QUERIES);
const rows = async (sql) => (await reader.query(sql)).rows;
// identical to the accepted v3-integration-core observeState
const [versions, entries, policyRows, controlRows] = await Promise.all([rows(QUERIES.catalogVersions), rows(QUERIES.catalogEntries), rows(QUERIES.policy), rows(QUERIES.controls)]);
const obs = { versions, entries, policyRows, controlRows };
const nowIso = new Date().toISOString().replace(/\.\d+Z$/, "Z");
console.log("BEFORE checkPreActivationState:", JSON.stringify(checkPreActivationState(obs, nowIso)));
const e0 = entries.find((e) => e.id === "openai-gpt-5-6-terra-standard-short-v1-reasoning-input-token-base");
const x0 = G.entryRows(G.V1.id, G.V1_RATES, G.V1.t0, G.V1.expiry, G.V1.source_digest, "inactive").find((e) => e.id === e0.id);
console.log("ACTUAL   unit_size", typeof e0.unit_size, JSON.stringify(e0.unit_size), " rate_micros", typeof e0.rate_micros, JSON.stringify(e0.rate_micros));
console.log("EXPECTED unit_size", typeof x0.unit_size, JSON.stringify(x0.unit_size), " rate_micros", typeof x0.rate_micros, JSON.stringify(x0.rate_micros));
console.log("canonical(actual)===canonical(expected) for this row:", G.canonicalize(e0) === G.canonicalize(x0));
const typemap = (rs, cols) => Object.fromEntries(cols.map((c) => [c, [...new Set(rs.map((r) => (r[c] === null ? "null" : typeof r[c])))].join("|")]));
console.log("ENTRY column types:", JSON.stringify(typemap(entries, Object.keys(entries[0]))));
console.log("VERSION column types:", JSON.stringify(typemap(versions, Object.keys(versions[0]))));
console.log("POLICY column types:", JSON.stringify(typemap(policyRows, Object.keys(policyRows[0]))));
console.log("CONTROL column types:", JSON.stringify(typemap(controlRows, Object.keys(controlRows[0]))));
// progressive surface proof: hand-convert one family at a time (diagnostic only; plain Number() on known-good test data)
const num = (rs, cols) => rs.map((r) => { const o = { ...r }; for (const c of cols) o[c] = Number(o[c]); return o; });
const E = ["unit_size", "rate_micros"], P = ["session_money_ceiling_micros", "session_provider_calls", "session_execution_admissions", "subject_day_money_ceiling_micros", "project_day_money_ceiling_micros", "project_month_money_ceiling_micros", "global_day_money_ceiling_micros"], C = ["control_epoch"];
const v12 = (e) => e.catalog_version_id !== G.V3_ID;
const entriesPredOnly = entries.map((e) => (v12(e) ? num([e], E)[0] : e));
console.log("STEP1 predecessor entries only →", JSON.stringify(checkPreActivationState({ ...obs, entries: entriesPredOnly }, nowIso)));
console.log("STEP2 + policy →", JSON.stringify(checkPreActivationState({ ...obs, entries: entriesPredOnly, policyRows: num(policyRows, P) }, nowIso)));
console.log("STEP3 + controls →", JSON.stringify(checkPreActivationState({ ...obs, entries: entriesPredOnly, policyRows: num(policyRows, P), controlRows: num(controlRows, C) }, nowIso)));
console.log("STEP4 + V3 entries →", JSON.stringify(checkPreActivationState({ ...obs, entries: num(entries, E), policyRows: num(policyRows, P), controlRows: num(controlRows, C) }, nowIso)));
await phys.close();

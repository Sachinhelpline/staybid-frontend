#!/usr/bin/env bash
set -u
cd "$(dirname "$0")/.." || exit 3
T=0; F=0
run(){ name="$1"; shift; "$@" >"tests/out/${name}.log" 2>&1; rc=$?; if [ $rc -eq 0 ]; then echo "PASS $name"; T=$((T+1)); else echo "FAIL $name rc=$rc"; cat "tests/out/${name}.log"; F=$((F+1)); fi; }
run digest node src/v3-digest-gen.mjs
run sql-check node tools/build-sql.mjs --check
run core node tests/core.test.mjs
run predecessor node tests/predecessor-compat.test.mjs
run sql-static node tests/sql-static.test.mjs
run runtime-static node tests/runtime-static.test.mjs
run evidence-static node tests/evidence-static.test.mjs
for f in src/*.mjs tools/*.mjs tests/*.mjs; do node --check "$f" >/dev/null 2>&1 || { echo "FAIL syntax $f"; F=$((F+1)); }; done
if [ $F -eq 0 ] && [ $T -eq 7 ]; then echo "RESULT: PASS (7/7 required checks)"; exit 0; fi
echo "RESULT: FAIL (pass=$T fail=$F)"; exit 1

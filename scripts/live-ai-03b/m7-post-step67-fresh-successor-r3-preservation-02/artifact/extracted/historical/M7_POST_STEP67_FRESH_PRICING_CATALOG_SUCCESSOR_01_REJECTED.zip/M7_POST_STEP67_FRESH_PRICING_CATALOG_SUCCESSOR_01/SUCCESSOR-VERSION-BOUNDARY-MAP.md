# Successor version boundary map

| Concern | V3 treatment | Frozen predecessor treatment |
|---|---|---|
| Pricing evidence / freshness | New T0, expiry, evidence receipt | V2 T0/expiry immutable |
| Catalog identity / digests | New V3 catalog + 3 entries | V1/V2 preserved inactive |
| One-call policy | Reuse `oneprobe-v2`, 105920 | No policy rewrite |
| Controls | Reuse dormant epoch-1 before catalog activation | No control rewrite |
| Approval | New `PricingEvidenceApprovalV3` | V2 approval contract historical |
| Runtime source authority | External preservation pin ref required | Existing accepted source-pin concept retained |
| Runtime config | New `V3` version contract, same AI-STAGING IDs + reviewer trust root | Security identifiers unchanged |
| Read registry/state | V3-specific 3-version / 8-entry state contract | V1/V2 rows exact historical checks |
| Activation adapter | Fixed `trusted_v3.activate_catalog_v3` one-shot SQL | trusted_v2 not invoked/edited |
| DB authority | New additive `live_ai_03b_trusted_v3` only | M6/trusted_v2 schemas untouched |
| Ledger | Reuse accepted `approval_consumption` | No ledger DDL/delete |
| Reader attestation | Reuse accepted same-session security architecture at future integration | No redesign |
| Executor attestation | Reuse accepted issuer/channel/binding | No redesign |
| Reviewer key | Reuse Owner-controlled production reviewer trust root | No new key generation |
| Gateway | Remains offline | No deployment |

## Future integration rule

The preserved successor must be wired into the existing production authority through the same accepted security seams. The integration may replace only version-bound V2 catalog/approval/runtime imports with the reviewed V3 equivalents. It must not weaken connection identity, role binding, attestation, distinct-client, clock, one-shot, or no-retry controls.

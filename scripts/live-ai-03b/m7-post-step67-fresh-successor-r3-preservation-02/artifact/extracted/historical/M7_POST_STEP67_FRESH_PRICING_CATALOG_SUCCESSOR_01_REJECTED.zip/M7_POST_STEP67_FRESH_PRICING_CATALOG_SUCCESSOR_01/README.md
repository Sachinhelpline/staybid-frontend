# M7 POST-STEP67 — Fresh Pricing / Catalog Successor 01

**Status:** consolidated OFFLINE successor candidate. **No live authorization.**

This package exists because the accepted V2 pricing verification window ended at `2026-10-05T15:26:23Z`. The accepted governance rule is HOLD after expiry; V2 T0/expiry must never be extended, patched or regenerated. This package therefore adds a new V3 freshness successor and treats V1/V2 as immutable history.

## Fresh official pricing verification

Fresh verification time / V3 T0: `2026-10-06T22:44:42Z`  
V3 verification expiry: `2026-10-13T22:44:42Z`

Official OpenAI documentation was freshly checked at generation time. Current direct / Standard / `service_tier=default` / non-regional / short-context facts remain:

- input: USD 2.00 / 1M tokens;
- cached input: USD 0.20 / 1M tokens (observed, but not a separate StayBid authority dimension);
- cache write: USD 2.50 / 1M tokens;
- output: USD 12.00 / 1M tokens;
- regional processing is a separate uplift and is excluded;
- `service_tier=default` is required to force Standard pricing/performance instead of project-controlled `auto` behavior.

Because the reviewed rates did not change, the existing one-call economic authority is reused unchanged:
`live-ai-03b-policy-oneprobe-v2`, digest `864e24817b2f98d741495bb403c20ada31cd4f27db3d9dfe1c50bb7d99ad9245`, worst-case ceiling `105920` micros.

## New additive successor identity

- catalog: `openai-gpt-5-6-terra-standard-short-v3`
- source digest: `13c536bcc4afbc6d2706468f072528fc4f7737919c6917653218eb861964ba9a`
- inactive catalog digest: `414d4844d10222473b68e2574676fcc3049e025b6b84f2c32a1fbf3c73bd9d74`
- active catalog digest: `bc38931203f797d0360818de429e618a1407fc7f9065f9da7257e6c686c10558`
- activation bundle digest: `6daa1c678589124cc9a0b01ab7d54aa8b0f46f1d80f4489c0f54cc6cbcacd8bc`
- predecessor parent: `37349fe9b33bb1045d0c7b062d4b5c4d7c330c1d`

## What is implemented

1. deterministic V3 source/catalog/bundle digests with V1/V2 canonical self-checks;
2. strict V3 catalog freshness/row contract;
3. `PricingEvidenceApprovalV3` + independent Ed25519 trust-root verifier;
4. signed binding to an **external successor runtime preservation pin ref**; missing/unresolved pin fails closed;
5. additive V3 runtime config, exact read-query registry, pre/activated state contract, and one-shot restricted activation adapter;
6. additive SQL candidate:
   - seed V3 only;
   - new `live_ai_03b_trusted_v3` schema;
   - `activate_catalog_v3` and ledger-correlated `restore_catalog_v3_inactive`;
   - V1/V2 exact predecessor checks;
   - no policy/control mutation;
   - PUBLIC revoked, executor-only function execution;
7. fresh supplied-evidence candidate and unsigned approval template;
8. fail-closed offline test runner.

## Deliberate preservation boundary

This package does **not** fabricate its own future Git preservation identity. `successor_runtime_pin_ref` is supplied only after an independently accepted preservation binding is available. The approval verifier refuses a missing/malformed/wrong pin ref. This prevents an unpreserved candidate from becoming live authority.

The package also does not rewrite the already frozen Production Reader V2 / Executor Attester / Reader Attester / Reviewer trust-root security mechanisms. The next integration must bind these V3 version-specific modules into the same accepted security seams without weakening them.

## Not done

- no Railway write;
- no DB connection (including no throwaway PostgreSQL);
- no SQL execution;
- no SQL03/V2 activation;
- no production composition `.run()`;
- no provider call;
- no reviewer production approval signature;
- no Git commit/push/PR;
- no gateway deploy;
- no CORE-PROD access.

## Test result

Run `bash tests/run-all.sh`.

Expected: `RESULT: PASS (7/7 required checks)`.

These are deterministic/static offline checks. They do **not** claim the historical full 44-suite predecessor runner or PostgreSQL lifecycle suites were rerun in this no-DB boundary.

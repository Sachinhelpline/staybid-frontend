# Fail-Closed / Rollback Plan — PI01 Live Readiness Remediation 01

This plan makes **no fake rollback guarantee**. Railway variable values are redacted to API readers, so the Owner
must keep their own out-of-band record of any value **before** changing it. Without such a record, a variable
change cannot be proven reversible.

## A. Fail-closed behaviour built into the candidate

**Authority standby:**
- Any missing or invalid configuration gives `composed:false` and one bounded reason.
- The process stays a passive standby: no listener, no DB, no attester request, no activation.
- A V2-era runtime contract, a V1-era executor issuer, a non-`railway.internal` attester destination, shared
  credentials/keys/secrets, forbidden secret classes, and a CORE-PROD or wrong-target anchor all refuse.

**Executor attester V2:**
- Static refusal happens before any I/O. The observer failure and setup failure paths destroy the physical
  connection.
- No V1 mode exists. V1 framing is refused (`unsupported_version`) and a V1 contract is refused (`bad_request`).
- Every adverse or uncertain measurement → `unavailable`, never signed.
- The conformance gate re-verifies every envelope with the frozen R3 V2 verifier before release.

**Accepted PI01 core (unchanged):**
- The runtime binding is pinned, the boundary is one-shot, and Executor V2 is the only executor path.
- Reader V2 is bound to the same session.
- After activation, any failure is `uncertain:true`. There is no retry and no automatic restore.

**One-shot runner:**
- The container lock is taken before any I/O.
- The advisory expiry check refuses at or after `2026-10-13T22:44:42Z`.
- There is exactly one `run()`. Exit 4 means UNCERTAIN.

## B. Safe rollbacks BEFORE any DB mutation (boundaries 2–5)

Each rollback is a separately authorized redeploy of the previous deployment. They are safe because no catalog,
ledger or role state has changed.

| Service | Roll back to | Effect |
|---|---|---|
| Executor attester `c74d7558` | deployment `5448b93a` (V1 runtime, source `caad383d`) | Restores the V1 issuer. The V3 Authority then correctly refuses (no V1 fallback), so this also implies an Authority rollback. |
| Authority `1f7daf27` | deployment `4c133737` (Step6/7 standby, source `37349fe9`) | Restores the fail-closed standby. Variable values (`V3`, connection ref) must be restored from the Owner's own record if rolled back. |
| Reader attester `2834ca5c` | restart / redeploy only (no variables changed) | Any Authority redeploy re-trips its latch, so after **any** Authority rollback the reader needs §4 of the readiness analysis again. |

Ordering for a full pre-mutation rollback: Authority → executor attester → reader attester. Each step is verified
read-only.

## C. MUST NOT be automatically retried or restored (after any DB mutation attempt)

- **Catalog activation with exit 4 / `uncertain:true`** (receipt absent or malformed, ledger cardinality or binding
  mismatch, activated-state mismatch, boundary throw):
  - Do **not** retry.
  - Do **not** run `restore_catalog_v3_inactive` / `m7-v3-06`.
  - Do **not** sign a new approval for the same execution.
  - Required: Owner read-only reconciliation (frozen R3 registry queries + the ledger row for the
    approval/execution ids). A restoration needs its own reviewed authorization **only after** the state is proven.
- **The one-shot lock** in a deployment is never removed to "try again". A new attempt needs a new deployment and a
  new authorization, after reconciliation proves no activation committed.
- **A consumed approval is single-use.** The ledger replay pre-check refuses it.
- **Any `ALTER ROLE` / schema prerequisite (boundary 7)** whose outcome is ambiguous: no rerun. Read-only
  verification of catalog state first; rollback only through its own reviewed rollback contract.

## D. What is NOT claimed

- That a redacted variable can be restored without the Owner's own record.
- That a reader-attester restart succeeds if RTT exceedance is ongoing or observer capacity is exhausted. Those are
  HOLD conditions (readiness analysis R3/R4).
- That this candidate proves any live value, live deployment or live DB state. All live facts stay UNKNOWN until
  verified.

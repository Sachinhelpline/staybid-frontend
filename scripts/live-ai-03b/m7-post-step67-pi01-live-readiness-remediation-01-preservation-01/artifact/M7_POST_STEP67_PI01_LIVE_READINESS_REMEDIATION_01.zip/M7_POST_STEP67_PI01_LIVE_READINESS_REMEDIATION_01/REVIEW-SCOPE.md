# Independent Review Scope — PI01 Live Readiness Remediation 01

Review exactly this candidate ZIP. The reviewer is asked to confirm or refute each item. Do not remediate.

## Identity
1. The ZIP opens, CRCs pass, and every `MANIFEST.json` entry matches its size and sha256; nothing is unlisted.
2. `IDENTITY-RECEIPT.json` verifies from a fresh `cbcb2689` checkout plus overlay
   (`tools/candidate-identity.mjs verify`).
   - All 58 frozen dependencies equal their `cbcb2689` blobs.
   - The 4 historical V1 executor files are unchanged.
   - The PI01 runtime materialization is byte-identical to the preserved artifact (21/21).
3. The anchor is `cbcb2689`, never `63d15b78`.

## Preservation of accepted semantics (must all hold)
4. The accepted PI01 files are byte-identical; `composeProductionActivationBoundaryV3` is called unchanged with
   exactly its 7 dependency keys; nothing calls `run()` except the one-shot runner.
5. Executor Attestation V2 only:
   - the Authority config requires the trust-root issuer `staybid.live-ai-03b.executor-attester.v2`;
   - the V2 server/client speak only `executor-attestation-channel-v2`;
   - V1 framing → `unsupported_version` and a V1 contract → `bad_request`;
   - V1 envelopes are refused by the frozen R3 verifier;
   - no V1 executor module is in any deployable import graph (static S01).
6. The V2 measurement (`executor-evidence-evaluator-v2.mjs`) is the frozen V1 measurement with **only** the
   expectation constants swapped to frozen R3 `EXPECTED_EXECUTOR_PRIVILEGES_V2`, plus the R3 evidence shape and an
   anchor-derived target (`evidence/ADAPTATION-executor-evidence-evaluator-v2.mjs.diff`). No check is weakened.
   - Real PG16: V3 state clean under V2; the frozen V1 evaluator refuses it; the drift matrix refuses.
7. The V2 observer/coordinator and the V2 server are 1:1 containment adaptations of the reviewed V1 issuer (diffs in
   `evidence/`). The observer setup-failure path destroys the physical connection (the accepted leak correction).
8. Reader V2 same-session binding: the reader provider passes the exact PI01-established session to the frozen Step6/7
   `acquireReaderV2Attestation`; the PI01 binder and connection separation are unchanged.
9. The runtime preservation binding is mandatory (PI01 pin + frozen R3 validation), and the one-shot is preserved.
10. No retry and no automatic restoration after an ambiguous mutation outcome (PI01 core, plus one-shot exit 4 and its
    lock).
11. Catalog expiry `2026-10-13T22:44:42Z` HOLDs: the advisory check in standby and the one-shot, the authoritative
    DB-clock check in the frozen R3 path. No T0/expiry regeneration.
12. There is no provider call, policy/control arm, gateway action, CORE-PROD target or G4/G5 path anywhere.
13. No secret value, private key or DB credential is in any file; there is no model identifier.

## Findings for decision (stated, not hidden)
- **F1 One-shot runner present.**
  - It is for FUTURE boundary 9 only and is not a start command; static S03 shows it is not in the standby graph.
  - It is included so that boundary 9 needs no new code. The reviewer may require its removal; removal does not
    affect A/B/C/D.
- **F2 Destinations.** The V3 Authority config additionally requires both attester destinations to be
  `*.railway.internal`; the V2-era loader accepted a literal private IP for the executor. The Step6/7 reference
  plan already uses `RAILWAY_PRIVATE_DOMAIN`. This is a tightening, not a relaxation.
- **F3 Executor V2 key.** Reusing the V1-era executor key for the V2 issuer is technically accepted (domain-separated
  payloads). A fresh V2 key is **recommended** and is an Owner decision. No key is generated or rotated here.
- **F4 Pre-existing regression failures**, unchanged by this candidate and identical on the pristine `cbcb2689`
  baseline:
  - V1 issuer `G11` (historical HEAD pin);
  - Step6/7 static `S04` (`provisioning-config.mjs` vs its old baseline);
  - V2-era `authority-provisioning.test.mjs` (pre-Step6/7 environment).
  - V1 issuer `G10` additionally flags this candidate's **untracked** additive files. That is a working-tree
    assertion and clears after Git preservation.
- **F5 Transitive constant dependency.** `first-text-probe-activation-01/first-text-probe.mjs` is reachable only via
  the frozen `v2-identity.mjs` (`PROBE_TEXT` constants). It imports only `node:crypto`, and nothing calls `runProbe`
  (static S26).
- **F6 Live facts remain UNKNOWN:**
  - variable values;
  - the source commit of `ba060a3b`;
  - the observer-role limit;
  - RTT health;
  - the executor peer allowlist.
  Each is a precondition in LIVE-VERIFY-PLAN, never assumed.

Verdict options:
- `ACCEPTED_LIVE_READINESS_REMEDIATION_01_READY_FOR_PRESERVATION`
- `HOLD_LIVE_READINESS_REMEDIATION_01_<EXACT_MATERIAL_BLOCKER>`

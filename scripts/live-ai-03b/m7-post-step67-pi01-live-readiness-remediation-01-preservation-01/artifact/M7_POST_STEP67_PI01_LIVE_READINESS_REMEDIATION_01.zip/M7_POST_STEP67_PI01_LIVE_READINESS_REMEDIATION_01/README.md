# M7 POST-STEP67 — PI01 LIVE READINESS REMEDIATION 01 (offline candidate)

**Status:** an OFFLINE, review-ready candidate. Nothing was deployed, preserved, signed or activated, and no live
system was contacted. It grants **no live authorization**.

**Authoritative base:** preservation commit `cbcb268939b2c8384188239ba8c228e8ca77c10d` (tree `36b25416…`;
parent / frozen R3 `f1e1f127…`).
- Accepted PI01 artifact: sha256 `d9c9c6ed…`, 25,341 bytes, Git blob `8e9cc8ce…`.
- Runtime digest `3e4be815…`; successor pin `78804a86…`.
- The superseded `63d15b78` (corrupt 6,024-byte blob `4333da91`) is **never** used as an authority anchor.

## What this candidate closes (implementation/design side only)

| Blocker | Resolution in this candidate |
|---|---|
| **A** — Authority PI01 runtime not deployable | Additive Authority V3 layer. It binds the **unchanged** accepted PI01 composition to real production deps (frozen pg factories, V2 executor channel, frozen Step6/7 reader V2 acquisition, V2-only trust root). It adds a fail-closed **standby start command** that composes but **never activates**, and a guarded **one-shot activation runner** for FUTURE boundary 9 only. |
| **B** — no deployable Executor Attestation V2 | Additive Executor Attester V2 service: config, entrypoint, authenticated `executor-attestation-channel-v2` server, client and V2 measurement. It uses the frozen R3 V2 issuer/signing/evidence-policy, with a conformance gate through the frozen R3 V2 verifier. **No V1 fallback, no V1→V2 translation**; V1 is refused at the config, channel and verifier levels. |
| **C** — Reader attester `PEER_INVALID` | **NO CODE CHANGE REQUIRED.** It is the intended sticky peer latch. The candidate gives the source-cited root cause, preconditions (source identity, clock health, observer-role capacity) and an exact controlled restart sequence to run **after** the final Authority deploy. |
| **D** — V3 variable values unverified | A variable-by-variable classification for the Authority and the executor attester, with exact V3 requirements and deterministic, value-free self-checks (the standby `composed` line and the executor `serving` line). |

## Package layout

- **Repo files** (`overlay/`, added at the same repo paths by the future Git preservation boundary):
  - `overlay/scripts/live-ai-03b/m7-post-step67-pi01-live-readiness-remediation-01/` — the new package
    (`src/`, `tests/`, `tools/`).
  - `overlay/scripts/live-ai-03b/m7-post-step67-production-integration-01-runtime-01/` — the accepted PI01 artifact
    materialized **byte-identically**: 21 entries, verified against the preserved ZIP at `cbcb2689`.
- **Documents:** `LIVE-APPLY-PLAN.md`, `LIVE-VERIFY-PLAN.md`, `FAIL-CLOSED-ROLLBACK-PLAN.md`,
  `VARIABLE-MIGRATION-PLAN.md`, `READER-ATTESTER-READINESS-ANALYSIS.md`, `REVIEW-SCOPE.md`,
  `IMPLEMENTATION-RECEIPT.md`.
- **Identity and evidence:** `IDENTITY-RECEIPT.json`, `MANIFEST.json`, and `evidence/` (test, regression, identity
  and syntax logs plus the V1→V2 adaptation diffs).

## Reproduce offline

1. Check out `cbcb2689` and copy `overlay/` onto the repo root.
2. Run:
   ```
   node scripts/live-ai-03b/m7-post-step67-pi01-live-readiness-remediation-01/tests/run-all.mjs
   node scripts/live-ai-03b/m7-post-step67-pi01-live-readiness-remediation-01/tools/candidate-identity.mjs verify IDENTITY-RECEIPT.json
   ```

`tests/localpg/` needs local PostgreSQL 16/18 binaries and the `pg` npm package. A skip (exit 2) is UNPROVEN, never
a pass.

# Future Live Apply Plan — PI01 Live Readiness Remediation 01

**Nothing in this document has been executed.** Each boundary below is DISTINCT and needs its own explicit Owner
authorization, with the read-only verification of LIVE-VERIFY-PLAN before and after it.
- There is no auto-retry and no fix-forward.
- UNKNOWN ≠ PASS.

These locks stand:
- SV-B and the historical G4 are consumed and never rerun.
- G5 is unauthorized.
- The gateway stays offline.
- CORE-PROD is untouched.

**Catalog window (hard).** The frozen R3 V3 catalog verification expiry is **`2026-10-13T22:44:42Z`** (DB clock):
- Boundaries 6–9 must complete before it.
- At or after it the V3 path HOLDs, both in the accepted PI01 `run()` and in the one-shot runner.
- T0/expiry is never regenerated.
- Continuing after expiry needs a new, separately reviewed successor; that is an Owner decision.

## Boundary list (the Owner's numbering) and dependency constraints

1. **Git preservation of this candidate.**
   - New branch from `cbcb2689`.
   - Add only the `overlay/` files of this ZIP at their repo paths, plus the documents.
   - Post-push remote byte verification (as in Preservation 01 Remediation 01).
   - Boundaries 2 and 4 deploy from that preserved commit.
2. **Executor Attester V2 Railway deployment** (service `c74d7558`).
   - Set the executor service V2 variables: VARIABLE-MIGRATION-PLAN §B — issuer = V2, signing key/public identity
     per the Owner key decision, observer credential, and anchor unchanged.
   - Switch the start command to `executor-attester-v2-entrypoint.mjs`, using the preserved commit.
   - Expected log: `serving`, `contract:"AiStagingExecutorAttestationV2"`, `protocol:"executor-attestation-channel-v2"`.
3. **Reader Attester controlled reconciliation/restart** (service `2834ca5c`).
   - Per READER-ATTESTER-READINESS-ANALYSIS §4, steps R1–R7.
4. **Authority V3 source/config deployment** (service `1f7daf27`).
   - Source = the preserved commit; start command = `authority-v3-standby-entrypoint.mjs`.
   - Set `LIVE_AI_03B_RUNTIME_CONTRACT_VERSION=V3` and `LIVE_AI_03B_CONNECTION_IDENTITY_PROOF_REF=staybid.live-ai-03b.executor-attester.v2`.
   - Expected: `PI01_V3_AUTHORITY_STANDBY {"composed":true,"reason":null,"successorRuntimePinRef":"78804a86…",…,"activationInvoked":false}`.
5. **V3 runtime variable verification/update.**
   - VARIABLE-MIGRATION-PLAN §A/§B, verified through the two deterministic self-check lines (no value reads).
   - Includes the executor `ALLOWED_PEER_CIDRS` update to the Authority's post-boundary-4 address.
6. **Live DB read-only preflight.**
   - The R3 pre-activation state (the frozen 5-query registry + `checkPreActivationState`): 3 versions / 8 entries,
     0 active, V3 inactive and byte-exact.
   - Executor role grant state (V2 measurement clean).
   - Observer role capacity (READER analysis R4).
   - Ledger has no consumption for the planned approval/execution ids.
7. **Any authorized live DB/schema prerequisite apply.**
   - Only if boundary 6 proves a prerequisite is missing.
   - For example the R3 V3 SQL `m7-v3-01`/`m7-v3-02` if not yet applied, or the reviewed observer-role
     `CONNECTION LIMIT` contract. Each has its own authorization.
8. **Genuine reviewer approval signing.**
   - Owner/reviewer only; never performed by this package.
   - A V3 approval binding `successor_runtime_pin_ref = 78804a8648e684bcdfb7d52dd34463310dec43c592fb2530216be19a04bc203d`.
9. **Catalog activation.**
   - Exactly once, inside the deployed Authority container, by the Owner:
     `node …/authority-v3-activation-oneshot.mjs --run-id <id> --request-file <path> --confirm-execution-id <id>`.
   - Exit `0` = activated + committed + correlated.
   - Exit `3` = refused, nothing activated.
   - Exit `4` = **UNCERTAIN — no retry, no restoration**; go to FAIL-CLOSED-ROLLBACK-PLAN §C.
   - A second attempt in the same deployment is refused by the one-shot lock.
10. **Post-activation verification.**
    - Read-only `checkActivatedState`: sole active V3, 3 active entries.
    - Committed-ledger correlation.
    - Policy/control still dormant; the probe and the gateway stay unauthorized.

## Recommended execution order (dependency-driven; boundaries stay distinct)

`1 → 2 → 4 → 5 → 3 → 6 → (7) → 8 → 9 → 10`

**Why 2 before 4.** The Authority's `EXECUTOR_ATTESTER_ISSUER`/`PUBKEY`/`FINGERPRINT`/`HOST`/`PORT`/`CHANNEL_SECRET`
are Railway references into the executor-attester service (Step6/7 `AUTHORITY_PLAN`). The Authority resolves the V2
issuer only if the executor service already carries it when the Authority deploys.

**Why 5 after 4.** The executor attester's `ALLOWED_PEER_CIDRS` is a literal Authority address, and every
Authority deploy changes it. After boundary 4:
- update `ALLOWED_PEER_CIDRS` to the new address;
- restart the executor attester (one controlled restart; same variables otherwise).

Until then the executor attester correctly refuses the Authority as `unauthenticated`.

**Why 3 after 4 and 5.** Every Authority deploy re-trips the reader attester's sticky peer latch (READER analysis
§2). A reader restart before the Authority's final deploy would be wasted.

**No further Authority deploy between 3 and 9.** Otherwise both attesters must be reconciled again.

## Start commands (exact, future)

- **Authority:** `node scripts/live-ai-03b/m7-post-step67-pi01-live-readiness-remediation-01/src/authority-v3-standby-entrypoint.mjs`
- **Executor attester:** `node scripts/live-ai-03b/m7-post-step67-pi01-live-readiness-remediation-01/src/executor-attester-v2-entrypoint.mjs`
- **Reader attester:** unchanged.

# V3 Variable Migration / Verification Plan — PI01 Live Readiness Remediation 01

**Rule:** NAME PRESENT ≠ VALUE VERIFIED. Every value below is **UNKNOWN** until verified with supported evidence.
- No secret value appears here.
- Verification of secrets is presence plus binding only, via deterministic self-checks that never print values.

**Self-checks that need no value reads by any human or agent:**
- **Authority:** the V3 standby start command logs `PI01_V3_AUTHORITY_STANDBY {"composed":…,"reason":…}`. It runs
  the full static V3 loader, so `composed:true` proves every Authority rule below. A failure reports one bounded
  reason code and no value.
- **Executor attester V2:** the start command logs `serving` (all static rules plus a successful observer session)
  or `unprovisioned` with one reason code.

**Classes:**
- **UNCHANGED** — must remain unchanged.
- **VERIFY** — must be verified before deploy.
- **CHANGE** — must change for V3.
- **SECRET** — secret; verify presence and binding only.
- **N/R** — not relevant to V3 apply.

## A. Authority `live-ai-03b-v2-authority` (`1f7daf27`) — 23 required names

| Name | Class | Exact V3 requirement (enforced by `authority-v3-config.mjs` + frozen R3 `loadRuntimeConfigV3`) |
|---|---|---|
| `LIVE_AI_03B_RUNTIME_CONTRACT_VERSION` | **CHANGE** | Exactly `V3`. The Step-2 era value is `V2`, so `V2`/`V1`/lowercase refuse (`runtime_config_v3_runtime_contract_not_v3`). |
| `LIVE_AI_03B_CONNECTION_IDENTITY_PROOF_REF` | **CHANGE** (unless already equal) | Exactly `staybid.live-ai-03b.executor-attester.v2`. It must also equal the executor trust-root issuer. |
| `LIVE_AI_03B_REVIEWER_TRUST_ROOT_DER_B64` | UNCHANGED + VERIFY | The accepted reviewer public key (R3 boundary map: "Reviewer trust root unchanged"). Ed25519 SPKI. |
| `LIVE_AI_03B_REVIEWER_TRUST_ROOT_FINGERPRINT` | UNCHANGED + VERIFY | sha256(SPKI) of the above; the loader recomputes it. |
| `LIVE_AI_03B_AI_STAGING_PROJECT_ID` | UNCHANGED + VERIFY | `4ad1abb3-823a-4acf-b889-6d34ae46d7f9` (exact). |
| `LIVE_AI_03B_AI_STAGING_ENVIRONMENT_ID` | UNCHANGED + VERIFY | `aa397bd7-b316-4fd8-b05a-0a5f6c5e3abc` (exact). |
| `LIVE_AI_03B_AI_STAGING_PG_SERVICE_ID` | UNCHANGED + VERIFY | `b7362594-a01b-4623-a982-394707a6cec2` (exact). |
| `LIVE_AI_03B_AI_STAGING_GATEWAY_SERVICE_ID` | UNCHANGED + VERIFY | `dd96c7cd-02c1-4d02-89eb-7e217930ebfa` (exact; an identity only — the gateway stays offline). |
| `LIVE_AI_03B_TRUSTED_EXECUTOR_DB_URL` | SECRET | Present. Executor-role credential (Step11B reference, "never touched"). Must differ from the reader URL (digest comparison). |
| `LIVE_AI_03B_TRUSTED_READER_DB_URL` | SECRET | Present. Reader-role credential. Must differ from the executor URL. |
| `LIVE_AI_03B_DEPLOYMENT_ANCHOR_JSON` | UNCHANGED + VERIFY | The accepted `AiStagingDeploymentAnchorV1` (a reference to the M5 attester anchor). Target = AI-STAGING; 64-hex cluster fingerprint. |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_ISSUER` | **CHANGE** (unless already equal) | Exactly `staybid.live-ai-03b.executor-attester.v2`. It is a **Railway reference** to the executor-attester service variable of the same name, so change it **there** (§B); the Authority picks it up on its next deploy. A V1-era issuer refuses (`executor_attester_issuer_not_v2`). |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_PUBKEY_DER_B64` | VERIFY (reference) | Equals the public key of the executor attester V2 **signing key** (§B). Must differ from the reader attester key. |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_FINGERPRINT` | VERIFY (reference) | sha256 of the above; the loader recomputes it. |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_HOST` | VERIFY (reference) | Must be `*.railway.internal`; the Step6/7 plan references the executor service `RAILWAY_PRIVATE_DOMAIN`. A literal IP refuses in V3. |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_PORT` | VERIFY (reference) | Equals the V2 service listen port (same name on both services). |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_CHANNEL_SECRET` | SECRET (reference) | Present, ≥ 32 chars, identical on both ends (by reference), ≠ reader channel secret. The protocol label changed `v1→v2` (it is inside the MAC input), so V1 traffic cannot authenticate. Rotation is optional (Owner decision); none is needed. |
| `LIVE_AI_03B_READER_ATTESTER_ISSUER` | UNCHANGED + VERIFY | The dedicated reader attester issuer (`staybid-live-ai-03b-authority-reader-attester-v1` per the Step6/7 plan). Must differ from the executor issuer. |
| `LIVE_AI_03B_READER_ATTESTER_PUBKEY_DER_B64` | UNCHANGED + VERIFY | The dedicated reader attester public key (reference). Must differ from the executor key. |
| `LIVE_AI_03B_READER_ATTESTER_FINGERPRINT` | UNCHANGED + VERIFY | sha256 of the above. |
| `LIVE_AI_03B_READER_ATTESTER_HOST` | UNCHANGED + VERIFY | `*.railway.internal` (a reference to the dedicated `RAILWAY_PRIVATE_DOMAIN`). |
| `LIVE_AI_03B_READER_ATTESTER_PORT` | UNCHANGED + VERIFY | The dedicated attester port. |
| `LIVE_AI_03B_READER_ATTESTER_CHANNEL_SECRET` | SECRET | Present, ≥ 32, ≠ executor channel secret. |
| `LIVE_AI_03B_EXECUTOR_STATEMENT_TIMEOUT_MS` (optional, V2-era) | N/R | The accepted PI01 core fixes the executor at 10 s and the reader at 2 s; not read by the V3 path. |
| Forbidden classes (`OPENAI_*`, `CORE_*`, `*PRIVATE_KEY*`, `DATABASE_URL`, `PG*`, gateway secrets, reader transport secret, …) | must be **ABSENT** | The standby reports `forbidden_secret_class_present` if any is present. |

**Start command — Authority (CHANGE, at boundary 4):**
`node scripts/live-ai-03b/m7-post-step67-pi01-live-readiness-remediation-01/src/authority-v3-standby-entrypoint.mjs`.
- It replaces the Step6/7 standby.
- It never activates.
- `authority-v3-activation-oneshot.mjs` is **never** a start command.

## B. Executor attester service `live-ai-03b-executor-attester` (`c74d7558`) — V2 deployment

| Name | Class | Requirement |
|---|---|---|
| `LIVE_AI_03B_EXECUTOR_ATTESTER_ISSUER` | **CHANGE** | Exactly `staybid.live-ai-03b.executor-attester.v2`; any other value → `unprovisioned: executor_attester_issuer_not_v2`. |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_SIGNING_KEY_PKCS8_B64` | SECRET | Ed25519 PKCS#8. Must match the configured PUBKEY/FINGERPRINT (`signing_key_not_configured_identity` otherwise) and differ from the reader attester key. **Owner decision:** a fresh V2 key is recommended, so that no V1-era envelope key is reused across contracts. It is generated by the Owner outside this package; no rotation happens in this boundary. |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_PUBKEY_DER_B64` / `…_FINGERPRINT` | VERIFY (CHANGE if a fresh key) | Public identity of the signing key; exported to the Authority by reference. |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_PORT` | VERIFY | Listen port = Authority destination port. |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_CHANNEL_SECRET` | SECRET | As in §A. |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_OBSERVER_DB_URL` | SECRET | The executor-attester observer role, **distinct** from the reader attester observer role. Least privilege: `pg_read_all_stats` only (verified per request). The V2 observer uses `application_name=lai03b-executor-attester-v2-observer`. |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_BIND_HOST` | VERIFY | Literal private bind; a loopback or public bind refuses. |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_ALLOWED_PEER_CIDRS` | **CHANGE after boundary 4** | Must equal the Authority's **new** private address (/128 or /32) after the Authority V3 deploy. Every Authority redeploy changes it. |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_ALLOW_WILDCARD_BIND` | VERIFY | `true` only with a wildcard bind. |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_PROOF_LIFETIME_MS` (optional) | VERIFY | 1000…300000 (default 120000). |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_DEPLOYMENT_ANCHOR` | UNCHANGED + VERIFY | The accepted `AiStagingExecutorDeploymentAnchorV1` (cluster fingerprint incl. executor role oid). The R3 V3 SQL does not change the database or executor role oids. |
| `LIVE_AI_03B_EXECUTOR_ATTESTER_DISTINCT_READER_ISSUER` / `…_DISTINCT_READER_FINGERPRINT` | VERIFY | Must name the reader attester the Authority actually uses (the **dedicated** `2834ca5c` identity). |
| Reader attester secrets / executor + reader DB URLs / gateway / provider / CORE | must be **ABSENT** | Enforced by the frozen loader (`foreign_credential_present`). |

**Start command — executor attester (CHANGE, at boundary 2):**
`node scripts/live-ai-03b/m7-post-step67-pi01-live-readiness-remediation-01/src/executor-attester-v2-entrypoint.mjs`.
- The V1 entrypoint is no longer started.
- There is no dual-protocol service.

## C. Dedicated reader attester (`2834ca5c`) — no variable change

All reader-attester names stay UNCHANGED. `LIVE_AI_03B_READER_SERVICE_NAME` remains the Authority
`RAILWAY_PRIVATE_DOMAIN` reference, and the name is stable across redeploys.

`LIVE_AI_03B_ATTESTER_OBSERVER_DB_URL` is shared by reference with the M5 attester (AD-2). Its role-capacity
precondition is in READER-ATTESTER-READINESS-ANALYSIS §3/R4.

## D. Not relevant to V3 apply

These must stay untouched:
- the M5 reader-attester / reader-host variables beyond the shared observer note;
- every gateway service variable — the gateway stays offline;
- every CORE-PROD variable.

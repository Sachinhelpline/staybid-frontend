# Reader Attester Readiness Analysis — PI01 Live Readiness Remediation 01

**Service:** `live-ai-03b-authority-reader-attester` `2834ca5c-caf6-46b5-a39c-8ebb9cdaa348`, deployment
`ba060a3b-51b5-497e-8e1a-79d4b0afaf2b` (process online).

**Observed** (Owner read-only preflight, 2026-10-07):
- `status="PEER_INVALID"`
- `signingReady=false`
- `peerInvalid="peer_identity_changed"`
- `lastReasonClass="rtt_exceeds_max"`

## Conclusion: NO CODE CHANGE REQUIRED

The state is the accepted, intended **fail-closed peer latch**. The reader attester must never sign for a peer
whose private network identity changed underneath it, so the latch is working as designed.

Clearing it needs a **controlled restart or redeploy**. That restart must happen **after the Authority's final
network identity is established**, plus the read-only preconditions in §4.

No source change, threshold change, auto-clear or retry is proposed, and none would be safe:
- weakening the latch defeats the peer-binding guarantee;
- raising `RTT_MAX_MS` hides a real clock-quality fault.

## 1. Exact source path

All files are frozen at `cbcb2689`, under `private-reader-bootstrap-clock-peer-offline-01/`.

**Peer supervision** — `production-attester.mjs:57-60`, with `serviceName = cfg.readerServiceName`:
- The value comes from env `LIVE_AI_03B_READER_SERVICE_NAME`.
- In the Step6/7 dedicated plan that is a Railway reference to the **Authority's** `RAILWAY_PRIVATE_DOMAIN`
  (`m7-step67-…/controller/reference-plan.mjs`, `DEDICATED_PLAN`, "SOLE peer = the Authority's private service
  name").
- `onChange` → `attRef.invalidatePeer("peer_identity_changed")`.

**Resolver cadence** — `private-peer-resolver.mjs:115` and `:125`:
- The supervisor re-resolves every 30 s (`intervalMs` default 30000).
- It calls `onChange` when the validated address set differs from the previous set.

**Sticky latch** — `attester-bootstrap.mjs:120-131`:
- `invalidatePeer` sets `peerInvalid`, `signingReady=false`, `status=PEER_INVALID` and a new boot generation.
- It emits `peer_invalidated` with `recovery: "controlled_restart_required"`.
- Separately, `attester-bootstrap.mjs:154` defines `signingEnabledNow()`, which requires `peerInvalid === null`.
- Automatic clock recovery (`regateOnce`, `runRecovery`) restores only clock signing readiness. It **never** clears
  `peerInvalid`.

**`lastReasonClass` semantics** — `attester-bootstrap.mjs:128` and `:146`:
- `invalidatePeer` first writes the peer class.
- Any later **clock** invalidation (`onMonitorInvalid`) overwrites `lastReasonClass` with the clock reason. Status
  stays `PEER_INVALID` because `peerInvalid !== null`.
- So `lastReasonClass="rtt_exceeds_max"` means: **after** the peer latch, at least one clock sample's monotonic
  round trip exceeded `RTT_MAX_MS = 100` (`clock-interval.mjs:24`, refused at `:69`).
- It is the *last* invalidation reason, not proof of a persistent condition. Whether RTT exceedance is ongoing is
  **UNKNOWN**.

**Heartbeat** — `attester-bootstrap.mjs:273-279`:
- Every 60 s it emits `state` with `status`, `signingReady`, `monitorHealthy`, `recovering`, `recoveryAttempt`,
  `peerInvalid` and `lastReasonClass`.
- `monitorHealthy` and `recovering`/`recoveryAttempt` separate "latched only" from "clock currently failing".

## 2. Most likely trigger (inference — NOT proven)

The Authority (`1f7daf27`) was redeployed to the Step6/7 standby (deployment `4c133737`, source `37349fe9`).

A Railway redeploy replaces the container. The Authority's `RAILWAY_PRIVATE_DOMAIN` then resolves to a new private
address, which the supervisor reports as `onChange`.

This matches every observed field. It becomes fact only after the read-only check in §4 step R1.

**Consequence:** every future Authority redeploy (FUTURE boundary 4) **re-trips** the latch. Restarting the reader
attester before the Authority's final deploy would therefore be wasted and misleading.

## 3. Observer-leak correction and role capacity (both UNKNOWN live)

**Leak correction.** `makeClosingObserverProvider` (commit `caad383d`) is present at `cbcb2689`:
- `production-attester.mjs` blob `18e223de…` is byte-identical to the reviewed budget-fix candidate.
- Whether deployment `ba060a3b` runs it is **UNKNOWN**: its source commit was not in the preflight evidence.
- A restart of an older deployment restarts the leaky provider. In that case the remedy is a **redeploy from a
  commit at or after `caad383d`** (for example the future preservation commit), not a plain restart.

**Role capacity.** AD-2 has the dedicated attester reuse the M5 attester's observer credential by reference, so
both processes share role `live_ai_03b_attester_observer`:
- the accepted budget is 2 per process, so 4 steady and 5 for a single transient;
- the role's live limit was 3 when last proven;
- `ALTER ROLE … CONNECTION LIMIT 5` (Remediation 01 contract, ZIP `f52d5851…`) was never authorized, and whether it
  was applied is **UNKNOWN**.

If the M5 attester (`3a7e5f80`) still runs, a restart can fail with SQLSTATE 53300 and leave the attester
`CLOCK_INVALID` or unprovisioned.

## 4. Future controlled reconciliation (FUTURE boundary 3 — NOT executed)

This step runs only after boundary 4 (Authority V3 deploy) and the executor peer-allowlist update are complete.
Each step is read-only unless marked **MUTATION**.

**R1 — Confirm the trigger (read-only).**
- Compare the Authority deployment `createdAt` with the reader attester's first `peer_identity_changed` or
  `peer_invalidated` log line.
- Expected: the first occurrence is within about 30 s after the Authority container replacement.
- If the trigger cannot be tied to an Authority replacement: **REFUSE / HOLD**. The cause may be an unsafe or
  hostile DNS change and needs investigation.

**R2 — Source identity (read-only).**
- Read deployment `ba060a3b` source metadata.
- If the source is older than `caad383d`, plan a **redeploy** from the preserved commit; otherwise a restart.
- If unknown: **HOLD**.

**R3 — Clock health (read-only).** Read the latest heartbeat.
- `monitorHealthy=true` and `recovering=false` → latched only; continue.
- `monitorHealthy=false` or persistent `recovering` → RTT/clock fault is live. **HOLD** and diagnose the DB round
  trip (network or DB load). Do **not** change `RTT_MAX_MS`.

**R4 — Observer role capacity (read-only; needs the live DB read-only preflight, boundary 6, or an equivalent
read-only authority).**
- `rolconnlimit` of `live_ai_03b_attester_observer`.
- Current sessions of that role, from `pg_stat_activity`, by `usename` and `application_name`.
- Which attester processes are running.
- Requirement: headroom ≥ 1 for the restarting process, so `limit − sessions_after_shutdown ≥ 2`.
- Otherwise **HOLD**. The capacity fix is the separately reviewed `ALTER ROLE` contract under its own DB
  authorization.

**R5 — Authority identity final (read-only).**
- The Authority V3 deployment is SUCCESS.
- Its standby line shows `composed:true`.
- No further Authority deploy is planned before activation.

**R6 — MUTATION (separately authorized).** Controlled restart of `2834ca5c`, or redeploy per R2.
- No variable change and no key rotation.
- Exactly one attempt. If startup fails, **HOLD**; there is no auto-retry loop.

**R7 — Postconditions (read-only).** Heartbeat within 60 s or more shows all of:
- `status` ∈ {`BOOTSTRAP_LISTENING`} (signing ready);
- `signingReady=true`, `peerInvalid=null`, `monitorHealthy=true`, `recovering=false`;
- a fresh `lastReasonClass` (`null` after a clean start);
- no `peer_identity_changed` event after the restart.

**Refusal conditions:**
- R1 unexplained;
- R2 unknown;
- R3 unhealthy;
- R4 no headroom;
- an Authority deploy still pending;
- startup gate failure (5 consecutive valid samples not reached);
- any `peer_unsafe:*` event.

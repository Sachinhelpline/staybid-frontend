# Future Live Verification Plan — PI01 Live Readiness Remediation 01

All checks are **read-only**: Railway status, deployment metadata and logs; DB `SELECT` only through the accepted
read-only roles.
- Secret values are never read or printed.
- A check that cannot be completed is **UNKNOWN**, which is a HOLD.
- Verifications are run fresh at each boundary; a cached result is never reused.

## Before any boundary
- **V-0.1** The project/environment is `4ad1abb3-…` / `aa397bd7-…`; staged changes = NONE.
- **V-0.2** The gateway `dd96c7cd` is offline with no deployment; CORE-PROD (`04c8b523…` / `1fbd7632…`) is not
  targeted by any command.
- **V-0.3** DB clock is before `2026-10-13T22:44:42Z`, with margin for boundaries 6–9.
- **V-0.4** The preserved candidate commit's remote bytes are verified (boundary 1 receipt).

## Boundary 2 — Executor Attester V2
- **V-2.1** The deployment source equals the preserved commit; the start command equals the V2 entrypoint.
- **V-2.2** Log `{"status":"serving","contract":"AiStagingExecutorAttestationV2","protocol":"executor-attestation-channel-v2","issuer":"staybid.live-ai-03b.executor-attester.v2","keyId":<fingerprint>}`.
  - `keyId` must equal `LIVE_AI_03B_EXECUTOR_ATTESTER_FINGERPRINT` (a public value).
- **V-2.3** No `unprovisioned` / `observer_lost` line.
- **V-2.4** In the DB (boundary 6 or an equivalent read-only check), exactly one session with
  `application_name='lai03b-executor-attester-v2-observer'`.

## Boundary 4 — Authority V3 standby
- **V-4.1** Source = the preserved commit; start command = `authority-v3-standby-entrypoint.mjs`.
- **V-4.2** The log line `PI01_V3_AUTHORITY_STANDBY` has:
  - `composed:true` and `reason:null`;
  - `successorRuntimePinRef:"78804a8648e684bcdfb7d52dd34463310dec43c592fb2530216be19a04bc203d"`;
  - `executorAttestationContract:"AiStagingExecutorAttestationV2"` and `v1Fallback:false`;
  - `requiredNamesPresent:true`;
  - `catalogWindow:"open_advisory"`;
  - `dbConnections:0`, `attesterRequests:0`, `listener:false`, `activationInvoked:false`.
- **V-4.3** If `composed:false`: the bounded `reason` code identifies the failing rule (VARIABLE-MIGRATION-PLAN).
  **HOLD.** No activation is possible in that state.

## Boundary 5 — variables + executor peer allowlist
- **V-5.1** The executor `ALLOWED_PEER_CIDRS` equals the Authority's current private address (Railway metadata).
- **V-5.2** After the executor restart, V-2.2 holds again.

## Boundary 3 — Reader attester
- READER-ATTESTER-READINESS-ANALYSIS R1–R5 before the restart and R7 after it.
- Expected heartbeat: `status:"BOOTSTRAP_LISTENING"`, `signingReady:true`, `peerInvalid:null`, `monitorHealthy:true`.

## Boundary 6 — live DB read-only preflight
- **V-6.1** The R3 frozen registry queries return a state accepted by the frozen R3 `checkPreActivationState(obs, dbNow)`:
  - 3 versions / 8 entries;
  - V1/V2 byte-exact predecessors;
  - V3 inactive and byte-exact;
  - policy/controls dormant.
- **V-6.2** The executor grant state is measured clean by the V2 measurement (offline-proven queries, observer
  role): 3 trusted schemas, 6 routines, 0 budget/ledger privileges, no widening.
- **V-6.3** Observer role capacity and headroom (READER analysis R4).
- **V-6.4** No ledger row for the planned approval/execution ids.

## Boundary 9 — activation (inside the Authority container, Owner-run)
- **V-9.1** Before the run: V-4.2, V-2.2 and the reader heartbeat (boundary 3) all hold at that moment; the DB clock
  is before expiry.
- **V-9.2** The one-shot output line has a `status`. If `"activated"`, it carries the `approvalId`, `executionId`,
  `consumedAt` and `successorRuntimePinRef`.
- **V-9.3** Exit `4` → STOP; FAIL-CLOSED-ROLLBACK-PLAN §C only.

## Boundary 10 — post-activation
- **V-10.1** The frozen `checkActivatedState`: sole active V3, 3 active entries, predecessors byte-exact,
  policy/controls still dormant.
- **V-10.2** Exactly one committed ledger row matching the receipt; `probeReady:false`; the gateway still offline.
